<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

$user = User::findOrFail(6);
$user = auth()->user();

class Candidat extends Model
{
    use HasFactory;

    protected $guarded = [];
    protected $casts = [
        'location' => 'array',
        'date_naissance' => 'array',
    ];

    /**
     * Relation : Le dossier de candidature appartient à un Utilisateur
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }    
    
}
