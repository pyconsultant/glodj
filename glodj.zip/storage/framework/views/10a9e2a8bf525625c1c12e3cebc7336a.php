<p
    <?php echo e($attributes->class(['fi-ta-empty-state-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /var/www/html/glodj/vendor/filament/tables/resources/views/components/empty-state/description.blade.php ENDPATH**/ ?>